// server/index.js

const express = require("express");
const fs = require('fs');
const bodyParser = require('body-parser');
const app = express();
const PORT = process.env.PORT || 3001;

// create application/json parser
var jsonParser = bodyParser.json();

//get from server 
app.get("/api/travellers", (req, res) => {
  let rawdata = fs.readFileSync('db.json');
  let travellers = JSON.parse(rawdata);
  res.json(travellers);
});

app.post("/api/add", jsonParser, (req, res) => {
  const newReservation = req.body.data;
  const rawdata = fs.readFileSync('db.json');
  let obj = JSON.parse(rawdata);
  let lst = obj.reservations;
  const currentDate = new Date();
  lst.push({
    serialNumber: newReservation.id,
    name: newReservation.name,
    phone: newReservation.phone,
    timeStamp: currentDate.toJSON(),
    seat: newReservation.seat
  });
  fs.writeFileSync('db.json', JSON.stringify(obj)
  );
  res.send('OK');
});

app.post("/api/delete", jsonParser, (req, res) => {
  const deletedSerialNumber = req.body.data.serialNumber;
  const rawdata = fs.readFileSync('db.json');
  const obj = JSON.parse(rawdata);
  const lst = obj.reservations;
  const filtered = lst.filter((reservation)=>{
    return !(reservation.serialNumber == deletedSerialNumber);
  });
  const newObj = {reservations: filtered}
  fs.writeFileSync('db.json', JSON.stringify(newObj)
  );
  res.send('OK');
});

app.listen(PORT, () => {
  console.log(`Server listening on ${PORT}`);
});