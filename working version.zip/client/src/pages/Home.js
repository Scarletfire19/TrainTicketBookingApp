const Home = (props) => {
    return (
        <div>
            <br/>
            <h1> Welcome to <br/>Train Reservation System</h1>
        </div>
    )
}

export default Home
