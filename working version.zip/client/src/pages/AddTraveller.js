import {useEffect, useState} from 'react'
import { nanoid } from 'nanoid'
import axios from 'axios'

const AddTraveller = () => {
    const [name, setName] = useState('')
    const [phone, setPhone] = useState('')
    const [seat, setSeatNumber] = useState('')
    const [seats, setSeats] = useState([])

    const onSubmit = (e) => {
        e.preventDefault()

        if(!name){
            alert('Please add a name')
            return
        }

        if(!phone){
            alert('Please add a phone number')
            return
        }

        if(!seat){
            alert('Please select a seat')
            return
        }
        const id = nanoid()
        handleAdd({ id, name, phone, seat })
    }

    const handleAdd = (data) => {
        axios.post("/api/add",
            {data},
            {"Content-Type":"application/json"},
        )
        .then(res => {
            if(res.data === 'OK') {
                alert('Successful reserved')
            } else {
                alert('Reservation failed')
            }
            cleanFields();
        }) 
    }

    const cleanFields = () => {
        setName('')
        setPhone('')
        setSeatNumber('')
    }

    useEffect( () => {
        const fetchData = async () => {
          const result = await axios(
            '/api/travellers',
          );
          const occupiedSeats = result.data.reservations.map((element) => {
            return element.seat;
            })

            const availableSeats =  Array.from({length: 25}, (x, i) => (i+1).toString()).filter((x) => {
                return !occupiedSeats.includes(x);
            });
            setSeats(availableSeats);
        };
        fetchData();
      }, [])

    return (
        <form className='add-form' onSubmit={onSubmit}>
            <div className='form-control'>
                <label>Name</label>
                <input type='text' placeholder='Add Name' value={name} 
                onChange={(e) => setName(e.target.value)}/>

            </div>
            <div className='form-control'>
                <label>Phone Number</label>
                <input type='text' placeholder='Add Phone Number' value={phone} 
                onChange={(e) => setPhone(e.target.value)}/>

            </div>
            <div className='form-control'>
                <label>Select seat</label>
                <select value={seat} onChange={(e) => setSeatNumber(e.target.value)} defaultValue="">
                    <option key="0" value="">Select an Option</option>
                    {seats.map((seat) =>
                    <option key={seat} value={seat} selected>{seat}</option>
                    )}
                </select>
            </div>
            <input type='submit' value='Save Reservation' className='btn btn-block' />
        </form>
    )
}

export default AddTraveller
