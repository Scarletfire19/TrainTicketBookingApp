import React, {useEffect, useState} from 'react'
import axios from 'axios'

export default function DisplayFreeSeats() {
  const [travellers, setTravellers] = useState([])

  useEffect( () => {
    const fetchData = async () => {
      const result = await axios(
        '/api/travellers',
      );

      setTravellers(result.data.reservations);
    };

    fetchData();
  }, [])

  return (
    <h3>Number of free seats : <span>{25 - travellers.length}</span></h3>
  )
}
