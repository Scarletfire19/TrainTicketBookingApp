import React, {useEffect, useState} from 'react'
import axios from 'axios'

export default function DeleteTraveller() {
    const [serialNumber, setSerialNumber] = useState('')
    const [travellers, setTravellers] = useState([])

    useEffect( () => {
        const fetchData = async () => {
          const result = await axios(
            '/api/travellers',
          );
          const reservations = result.data.reservations
          reservations.sort(function(a, b){return a.seat - b.seat});
          setTravellers(reservations);
        };
    
        fetchData();
      }, [])

    const onSubmit = (e) => {
        e.preventDefault()

        if(!serialNumber){
            alert('Please select a valid number')
            return
        }

        handleDelete({serialNumber})
    }

    const handleDelete = (data) => {
        axios.post("/api/delete",
            {data},
            {"Content-Type":"application/json"},
        )
        .then(res => {
            if(res.data === 'OK') {
                alert('Successful deleted')
            } else {
                alert('Deletion failed')
            }
            setSerialNumber('')
        }) 
    }
    
    return (
        <form className='add-form' onSubmit={onSubmit}>
            <div className='form-control'>
                <label>Select a reservation</label>
                <select value={serialNumber} onChange={(e) => setSerialNumber(e.target.value)} defaultValue="">
                    <option key="0" value="" selected>Select an Option</option>
                    {travellers.map((traveller) =>
                    <option key={traveller.serialNumber} value={traveller.serialNumber}>{`${traveller.seat}: ${traveller.name} (${traveller.serialNumber})`}</option>
                    )}
                </select>
            </div>
            <input type='submit' value='Delete Reservation' className='btn btn-block' />
        </form>
    )
}
