import React, {useEffect, useState} from 'react'
import Travellers from '../components/Travellers'
import axios from 'axios'

export default function DisplayTravellers() {
  const [travellers, setTravellers] = useState([])

  useEffect( () => {
    const fetchData = async () => {
      const result = await axios(
        '/api/travellers',
      );
      const reservations = result.data.reservations
      reservations.sort(function(a, b){return a.seat - b.seat});
      setTravellers(reservations);
    };

    fetchData();
  }, [])

  return (
    <div>
        {travellers.length > 0 ? 
        (<Travellers travellers={travellers}/>) 
        : ('No Travellers To Show')}
    </div>
  )
}

