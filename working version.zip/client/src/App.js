
import AddTraveller from './pages/AddTraveller'
import DisplayTravellers from './pages/DisplayTravellers'
import DeleteTraveller from './pages/DeleteTraveller.js'
import DisplayFreeSeats from './pages/DisplayFreeSeats'
import Home from './pages/Home'
import React from 'react'
import './App.css';
import {Link, Route, Routes} from 'react-router-dom'

function App() {

  // const [data, setData] = React.useState(null);
  // React.useEffect(() => {
  //   fetch("/api")
  //     .then((res) => res.json())
  //     .then((data) => setData(data.message));
  // }, []);

  return (
    <div className="app-wrapper">
      <div className="navbar">
          <Link className='list-group-item' to="/">Home</Link>
          <Link className='list-group-item' to="/add">Add Traveller</Link>
          <Link className='list-group-item' to="/delete">Delete Traveller</Link>
          <Link className='list-group-item' to="/display">Display Traveller</Link>
          <Link className='list-group-item' to="/seats">Display Free Seats</Link>
      </div>
      <div className="container">
        <Routes>
          <Route path='/' element={<Home/>} />
          <Route path='/add' element={<AddTraveller/>} />
          <Route path='/display' element={<DisplayTravellers/>} />
          <Route path='/delete' element={<DeleteTraveller/>} />
          <Route path='/seats' element={<DisplayFreeSeats/>} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
