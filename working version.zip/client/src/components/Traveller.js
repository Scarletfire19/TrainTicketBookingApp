import {FaTimes} from 'react-icons/fa'

const Traveller = ({ traveller, onDelete}) => {
    return (
        <div className={'traveller'} >
            <h5>{traveller.serialNumber}</h5>
            <h3>{traveller.name}</h3>
            <p><b>Mobile:</b> {traveller.phone}</p>
            <p><b>Seat Number:</b> {traveller.seat}</p>
        </div>
    )
    /*<div className={`traveller ${traveller.reminder ? 'reminder' : ''}`} onDoubleClick={() => onToggle(traveller.id)}> */
}

export default Traveller
