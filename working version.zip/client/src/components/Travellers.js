import Traveller from './Traveller'


const Travellers = ({ travellers}) => {
    
    return (
        <>
            {travellers.map((traveller) => (
                <Traveller key={traveller.id} traveller={traveller}/>
            ))}
        </>
    )
}

export default Travellers


